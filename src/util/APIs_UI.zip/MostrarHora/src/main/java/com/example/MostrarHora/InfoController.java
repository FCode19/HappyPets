
package com.example.MostrarHora;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class InfoController {
    @GetMapping(value = "/api/horario", produces = "text/plain")
    public String getHorario() {
        return "Huellitas\nHorario de atención:\nL-V: 8:00 a 17:00\nS-D: 9:00 a 17:00\nEmergencia: 24h";
    }
}
