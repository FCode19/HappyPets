
package com.example.MostrarHora;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FranjaHoraria {
    @GetMapping("/api/estado")
    public String getEstadoVeterinaria() {
        LocalTime ahora = LocalTime.now();
        DayOfWeek dia = LocalDate.now().getDayOfWeek();

        boolean abierto = switch (dia) {
            case SATURDAY, SUNDAY ->
                ahora.isAfter(LocalTime.of(9, 0)) && ahora.isBefore(LocalTime.of(17, 0));
            default ->
                ahora.isAfter(LocalTime.of(8, 0)) && ahora.isBefore(LocalTime.of(17, 0));
        };

        return abierto ? "Abierto ahora" : "Cerrado en este momento";
    }
}
